% Root Finding Methods
clear; clc;

% Define function and derivative
f = @(x) x.^5 - 2*x.^3 + 3*x - 1;
df = @(x) 5*x.^4 - 6*x.^2 + 3;

% Newton-Raphson (Recursive)
function root = newton(f, df, x, tol, iter)
    if iter > 50
        root = x;
        return;
    end
    
    x_new = x - f(x)/df(x);  % Newton formula
    
    fprintf('Iter %d: x = %.6f\n', iter, x_new);
    
    if abs(f(x_new)) < tol
        root = x_new;
        return;
    end
    
    root = newton(f, df, x_new, tol, iter+1);  % Recursive call
end

%% Secant Method (Recursive)
function root = secant(f, x0, x1, tol, iter)
    if iter > 50
        root = x1;
        return;
    end
    
    x_new = x1 - f(x1)*(x1-x0)/(f(x1)-f(x0));  % Secant formula
    
    fprintf('Iter %d: x = %.6f\n', iter, x_new);
    
    if abs(f(x_new)) < tol
        root = x_new;
        return;
    end
    
    root = secant(f, x1, x_new, tol, iter+1);  % Recursive call
end

%% Run both methods
fprintf('Newton-Raphson:\n');
root1 = newton(f, df, 1.0, 1e-6, 1);
fprintf('Final root: %.6f\n\n', root1);

fprintf('Secant Method:\n');
root2 = secant(f, 0.5, 1.5, 1e-6, 1);
fprintf('Final root: %.6f\n', root2);