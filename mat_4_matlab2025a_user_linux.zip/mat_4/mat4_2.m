%Combined Recursive vs Dynamic Programming Comparison
clear; clc;

%FIBONACCI SERIES SOLUTIONS
fprintf(' FIBONACCI SERIES COMPARISON \n');

% Recursive Fibonacci
function fib = fib_rec(n)
    if n <= 1
        fib = n;
    else
        fib = fib_rec(n-1) + fib_rec(n-2);
    end
end

% DP Fibonacci
function fib = fib_dp(n)
    if n <= 1
        fib = n;
        return;
    end
    dp = [0, 1];
    for i = 3:n+1
        dp(i) = dp(i-1) + dp(i-2);
    end
    fib = dp(end);
end

% Test Fibonacci
n_test = 20;
tic; fib_rec_result = fib_rec(n_test); t_rec = toc;
tic; fib_dp_result = fib_dp(n_test); t_dp = toc;

fprintf('Fibonacci(%d) = %d\n', n_test, fib_rec_result);
fprintf('Recursive: %.4f sec, Dynamic Programming: %.4f sec\n\n', t_rec, t_dp);

%KNAPSACK PROBLEM SOLUTIONS
fprintf(' KNAPSACK PROBLEM COMPARISON \n');

% Recursive Knapsack
function val = knap_rec(w, v, cap, n)
    if n == 0 || cap == 0
        val = 0;
    elseif w(n) > cap
        val = knap_rec(w, v, cap, n-1);
    else
        val = max(v(n) + knap_rec(w, v, cap-w(n), n-1), ...
                  knap_rec(w, v, cap, n-1));
    end
end

% DP Knapsack
function val = knap_dp(weights, values, capacity)
    n = length(weights);
    dp = zeros(n+1, capacity+1);
    
    for i = 1:n
        for w = 0:capacity
            if weights(i) <= w
                dp(i+1, w+1) = max(values(i) + dp(i, w+1-weights(i)), dp(i, w+1));
            else
                dp(i+1, w+1) = dp(i, w+1);
            end
        end
    end
    val = dp(end, end);
end

% Test Knapsack
weights = [2, 4, 5, 6];
values = [3, 4, 5, 6];
capacity = 5;

tic; knap_rec_result = knap_rec(weights, values, capacity, length(weights)); t1 = toc;
tic; knap_dp_result = knap_dp(weights, values, capacity); t2 = toc;

fprintf('Knapsack Max Value: %d\n', knap_rec_result);
fprintf('Recursive: %.4f sec, Dynamic Programming: %.4f sec\n\n', t1, t2);

% PERFORMANCE COMPARISON FOR DIFFERENT SIZES
% Fibonacci timing for different n
fib_sizes = 5:3:25;
fib_rec_times = zeros(size(fib_sizes));
fib_dp_times = zeros(size(fib_sizes));

for i = 1:length(fib_sizes)
    n = fib_sizes(i);
    
    % Skip very slow recursive calculations
    if n <= 20
        tic; fib_rec(n); fib_rec_times(i) = toc;
    else
        fib_rec_times(i) = NaN;
    end
    
    tic; fib_dp(n); fib_dp_times(i) = toc;
end

% Knapsack timing for different sizes
knap_sizes = 5:2:15;
knap_rec_times = zeros(size(knap_sizes));
knap_dp_times = zeros(size(knap_sizes));

for i = 1:length(knap_sizes)
    n = knap_sizes(i);
    w = randi([1, 10], 1, n);
    v = randi([5, 20], 1, n);
    cap = floor(sum(w) * 0.6);
    
    if n <= 12
        tic; knap_rec(w, v, cap, n); knap_rec_times(i) = toc;
    else
        knap_rec_times(i) = NaN;
    end
    
    tic; knap_dp(w, v, cap); knap_dp_times(i) = toc;
end

%PLOT COMPARISON GRAPHS
% Fibonacci comparison
figure;
plot(fib_sizes, fib_rec_times * 1000, 'ro-', 'LineWidth', 2, 'MarkerSize', 6);
hold on;
plot(fib_sizes, fib_dp_times * 1000, 'gd-', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Fibonacci Number (n)');
ylabel('Time (milliseconds)');
title('Fibonacci: Recursive vs DP');
legend('Recursive', 'Dynamic Programming');
grid on;

% Knapsack comparison
figure;
plot(knap_sizes, knap_rec_times * 1000, 'ro-', 'LineWidth', 2, 'MarkerSize', 6);
hold on;
plot(knap_sizes, knap_dp_times * 1000, 'gd-', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Number of Items');
ylabel('Time (milliseconds)');
title('Knapsack: Recursive vs DP');
legend('Recursive', 'Dynamic Programming');
grid on;